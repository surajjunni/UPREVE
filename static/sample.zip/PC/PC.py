import numpy as np
import pandas as pd
import itertools
import argparse
from castle.algorithms import PC

def pc_algorithm(data, alpha, variant, verbose=False):
    # Convert data to a numpy array
    data_array = np.array(data)
    print(data_array)
    # Get the number of variables
    obj=PC(alpha=0.05,variant=variant)
    obj.learn(data_array)
    adj_matrix = pd.DataFrame(obj.causal_matrix, columns=data.columns, index=data.columns)
    del adj_matrix[adj_matrix. columns[0]]
    return adj_matrix

def main():
    # Create the argument parser
    parser = argparse.ArgumentParser(description='Run PC algorithm with hyperparameters')
    
    # Add the arguments
    parser.add_argument('--data', type=str, help='Path to data file')
    parser.add_argument('--alpha', type=str, help='Significance level for conditional independence tests')
    parser.add_argument('--variant', type=str, help='Maximum number of lags to consider for time series variables')
    parser.add_argument('--output', type=str, help='Path to output file')
    
    # Parse the arguments
    args = parser.parse_args()
    df=pd.read_csv(args.data)
    # Call the PC algorithm function with the provided hyperparameters and save the output to a file
    adj_matrix=pc_algorithm(df, float(args.alpha), str(args.variant))
    adj_matrix.to_csv(args.output, index=False)
    
if __name__ == '__main__':
    main()